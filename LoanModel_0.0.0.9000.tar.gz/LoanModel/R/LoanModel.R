# Exec Loan Model
#
# This function named 'ExecLoanModel' executes a sample Regression Model
#
# You can learn more about package authoring with RStudio at:
#
#   http://r-pkgs.had.co.nz/
#
# Some useful keyboard shortcuts for package authoring:
#
#   Build and Reload Package:  'Ctrl + Shift + B'
#   Check Package:             'Ctrl + Shift + E'
#   Test Package:              'Ctrl + Shift + T'

ExecLoanModel <- function(FolderTimeStamp) {
  library(SparkR)
  library(sparklyr)
  library(dplyr)
  library(DBI)

  sparkR.session()
  sc <- spark_connect(method = "databricks")

  # Get The Job Timestamp Value
  print(FolderTimeStamp)
  ModelTableName = paste("finalloandata", FolderTimeStamp, sep="")
  PredTableName = paste("predloandata", FolderTimeStamp, sep="")

  # Divide the dataset on training and testing data
  partitions <- tbl(sc, ModelTableName) %>% sdf_partition(training = 0.75, test = 0.25, seed = 1099)
  # Create a hive metadata for each partition:
  #sdf_register(partitions,c("training","test"))

  # fit a linear model to the training dataset
  fit <- partitions$training %>% ml_linear_regression(loan_status ~ loan_amnt +
                                                        home_ownership + annual_inc + verification_status +
                                                        purpose + dti + int_rate + inq_last_6mths + mths_since_last_delinq +
                                                        revol_bal + revol_util + total_acc)
  # summarize the model
  #summary(fit)

  # Score the data
  pred <- sdf_predict(fit, partitions$test)
  # Register The Prediction As Temp Table
  pred_tbl <- sdf_register(pred, PredTableName)
  head(pred_tbl)
  #%>% dplyr::collect

  # Register The Prediction As Temp Table
  #pred_tbl <- dplyr::copy_to(sc, pred, name=PredTableName, overwrite = TRUE)

  # Save To Hive For Sharing With Python
  DBI::dbGetQuery(sc, "DROP TABLE IF EXISTS loan_pred_share")
  PredTableSQL = paste("CREATE TABLE loan_pred_share AS SELECT * FROM ", PredTableName, sep="")
  DBI::dbGetQuery(sc, PredTableSQL)

  # Drop Hive Temp Tables
  dplyr::db_drop_table(sc, ModelTableName)
  dplyr::db_drop_table(sc, PredTableName)

  # Disconnect From session
  spark_disconnect(sc)
}
